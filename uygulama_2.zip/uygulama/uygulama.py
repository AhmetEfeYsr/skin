from flask import Flask, request, jsonify, render_template
import cv2
import numpy as np
import mediapipe as mp
import os
import sqlite3
from werkzeug.utils import secure_filename

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

mp_face_mesh = mp.solutions.face_mesh

def get_db_connection():
    conn = sqlite3.connect('maybeline_newyork.db')
    conn.row_factory = sqlite3.Row
    return conn

def get_skin_tone(image_path):
    image = cv2.imread(image_path)
    if image is None:
        return None

    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    h, w, _ = image.shape
    skin_pixels = []

    with mp_face_mesh.FaceMesh(static_image_mode=True) as face_mesh:
        results = face_mesh.process(rgb_image)
        if not results.multi_face_landmarks:
            return None

        face_landmarks = results.multi_face_landmarks[0]
        sample_points = [10, 338, 297, 332, 284, 251, 389, 356, 454, 323]

        for idx in sample_points:
            pt = face_landmarks.landmark[idx]
            x = int(pt.x * w)
            y = int(pt.y * h)
            if 0 <= x < w and 0 <= y < h:
                skin_pixels.append(rgb_image[y, x])

        if not skin_pixels:
            return None

        avg_color = np.mean(skin_pixels, axis=0).astype(int)
        return tuple(avg_color)

def find_closest_maybelline_color(target_r, target_g, target_b):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT code FROM maybeline_newyork 
        ORDER BY ( (r - ?)*(r - ?) + (g - ?)*(g - ?) + (b - ?)*(b - ?) ) ASC
        LIMIT 1
    """, (target_r, target_r, target_g, target_g, target_b, target_b))
    result = cursor.fetchone()
    conn.close()
    return result['code'] if result else None

@app.route('/')
def index():
    return render_template('site.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'photo' not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files['photo']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    file.save(filepath)

    rgb_values = get_skin_tone(filepath)
    os.remove(filepath)

    if not rgb_values:
        return jsonify({"error": "Could not detect skin tone"}), 400

    maybelline_code = find_closest_maybelline_color(*rgb_values)
    if maybelline_code:
        return jsonify({"maybelline_code": maybelline_code})
    else:
        return jsonify({"error": "No matching color found"}), 400

if __name__ == '__main__':
    app.run(debug=True)